import DiscoverBanner from "./discover-banner";

export default function DiscoverLayout() {
    return (
        <div className="flex flex-1 flex-col gap-4">
            <DiscoverBanner />
        </div>
    );
}