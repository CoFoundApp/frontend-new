export default function IntroductionComplete() {
    return (
        <div className="bg-muted p-4 rounded-md">
            Presque terminé ! Il ne vous reste plus qu’à valider pour créer votre profil.
        </div>
    );
}