import IntroductionForm from "@/components/application/introduction/introduction-form";

export default function IntroductionPage() {
    return (
        <IntroductionForm />
    );
}